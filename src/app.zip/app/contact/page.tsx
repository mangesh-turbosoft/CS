import Image from "next/image";
import Link from "next/link";

const offices = [
  {
    img: "/images/uk-office.jpg",
    country: "UK",
    address: "124 City Road,\nLondon, EC1V 2NX",
    contactLabel: "Call or Text:",
    contactValue: "+44 7824 323288",
    contactHref: "tel:+447824323288",
  },
  {
    img: "/images/india-office.jpg",
    country: "INDIA",
    address: "Third Floor, Clover Metropole,\nNIBM Undri Road, Pune 411048",
    contactLabel: "Email:",
    contactValue: "hello@creativeskills.com",
    contactHref: "mailto:hello@creativeskills.com",
  },
];
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Creative Skills | Discuss Your Web Development Project",
  description:
    "Speak with our team about WordPress development, HubSpot CMS, Headless CMS, website support or your next digital project.",
  keywords: [
    "contact web developers",
    "wordpress development consultation",
    "hubspot cms experts",
    "headless cms agency",
    "website development quote",
    "web development enquiry",
    "website support services",
    "custom web development agency",
    "digital project consultation",
  ],
};
export default function Contact() {
  return (
    <div className="w-full font-sans">
      <section className="relative max-w-[1600px] mx-auto px-[50px] min-h-screen flex flex-col justify-center bg-white">
        <h1
          className="font-google-sans
            text-[#f04c3e]
            font-semibold
            leading-[1.1]
            mt-[0]
            mb-[30]
            text-[228px]
          "
        >
          Contact Us
        </h1>

        <p
          className="font-google-sans
            text-[#7b7b7b]
            font-medium
            max-w-full
            overflow-hidden
            clear-both
            mt-8
            text-[62px]
            leading-[72px]
          "
        >
          Get in touch to discuss your project or explore working together.
        </p>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[#e8412a]">
          <Link
            href="#next"
            className="
    absolute
    bottom-[40px]
    left-1/2
    -translate-x-1/2
    w-[30px]
    h-[30px]
    z-[999]
    animate-bounce
  "
          >
            <Image
              src="/images/inner-down-arrow.png"
              alt="Scroll Down"
              width={30}
              height={30}
              className="w-full h-full object-contain"
            />
          </Link>
        </div>
      </section>

      <section id="next" className="w-full bg-white border-t border-[#ebebeb]">
        <div className="flex flex-col sm:flex-row">
          {offices.map((office, i) => (
            <div key={i} className="flex-1 min-w-0">
              <img
                src={office.img}
                alt={`${office.country} office`}
                className="w-full object-cover mb-5"
                style={{ height: "60%" }}
              />
              <div style={{ padding: "5% 20% 10%" }}>
                <p
                  className="font-bold text-[#2a2a2a] mb-3"
                  style={{
                    color: "#f04c3e",
                    fontSize: "40px",
                    lineHeight: "42px",
                    marginBottom: "5px",
                  }}
                >
                  {office.country}
                </p>

                {/* Address lines — ~14px gray */}
                <address className="not-italic mb-3">
                  {office.address.split("\n").map((line, j) => (
                    <p
                      key={j}
                      className="text-[#666666] leading-relaxed"
                      style={{
                        fontSize: "30px",
                        color: "#5c5c5c",
                        lineHeight: "46px",
                      }}
                    >
                      {line}
                    </p>
                  ))}
                </address>

                <p
                  style={{
                    fontSize: "30px",
                    color: "#5c5c5c",
                    lineHeight: "46px",
                  }}
                >
                  <span className="text-[#666666]">{office.contactLabel} </span>
                  <a
                    href={office.contactHref}
                    className="text-[#f04c3e] hover:text-[#e8412a] transition-colors duration-200"
                  >
                    {office.contactValue}
                  </a>
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
