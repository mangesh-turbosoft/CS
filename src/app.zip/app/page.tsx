import Image from "next/image";
import Firstsec from "@/app/componants/Firstsec";
import Intro from "@/app/componants/Intro";
import CaseStudies from "@/app/componants/casestudies";
export default function Home() {
  return (
    <>
    <Firstsec />
    <Intro />
    <CaseStudies />
    </>
  );
}
