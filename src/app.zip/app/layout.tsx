import type { Metadata } from "next";
import "./globals.css";
import "aos/dist/aos.css";

import Header from "./componants/Header";
import Footer from "./componants/Footer";
import AosProvider from "./componants/AosProvider";

export const metadata: Metadata = {
  title: {
    default:
      "Expert Web Development Agency | WordPress, HubSpot & Headless CMS | Creative Skills",
    template: "%s | Creative Skills",
  },

  description:
    "Creative Skills delivers custom web development solutions using WordPress, HubSpot CMS and Headless CMS. Trusted by agencies and businesses worldwide.",

  keywords: [
    "web development agency",
    "wordpress development agency",
    "hubspot cms agency",
    "headless cms agency",
    "custom website development",
    "website development company",
    "wordpress experts",
    "hubspot developers",
    "headless cms developers",
    "web application development",
    "website support",
    "website optimisation",
    "digital agency partner",
  ],
};
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased flex flex-col min-h-screen">
        <AosProvider />

        <Header />

        <main className="flex-1">
          {children}
        </main>

        <Footer />
      </body>
    </html>
  );
}