
import Image from "next/image";
import Link from "next/link";

const challenges = [
  "Will the project be delivered to the quality we expect?",
  "Will the deadlines be adhered to?",
  "Will our design essence be fully understood?",
  "Will the project exceed its budget?",
];

const strengths = [
  "28 years of expertise in website development and outsourced solutions.",
  "Specialising in scalable, high-performance web applications.",
  "Expertise in modern frameworks, CMS platforms, and custom solutions.",
  "Seamless integration with client teams for smooth project execution.",
  "Cost-effective development with a focus on innovation.",
  "End-to-end support from planning to deployment and maintenance.",
];

import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Development Partner for Design Agencies | Creative Skills",
  description:
    "Extend your team's capabilities with experienced web developers. We help design agencies deliver WordPress, HubSpot and Headless CMS projects efficiently.",
  keywords: [
    "development partner for agencies",
    "web development white label",
    "wordpress development partner",
    "hubspot development partner",
    "outsourced web development",
    "agency web developers",
    "white label wordpress development",
    "design agency support",
    "headless cms development partner",
    "agency website development",
  ],
};

export default function DesignAgencies() {
  return (
    <>
      <section className=" max-w-[1600px] mx-auto px-[50px] py-24 flex flex-col justify-center bg-white">
        <div className="min-h-[60vh]">
          <h1 data-aos="fade-up"
            className="font-google-sans
            text-[#f04c3e]
            font-semibold
            leading-[1.1]
            mt-[0]
            mb-[30]
            text-[228px]
          "
          >
            Design Agencies
          </h1>
          <p data-aos="fade-up"
            className="font-google-sans
            text-[#7b7b7b]
            font-medium
            max-w-full
            overflow-hidden
            clear-both
            mt-8
            text-[62px]
            leading-[72px]
          "
          >
            You win the client with strategy and design.
            <br />
            We ensure the build matches your vision, pixel for pixel.
          </p>
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[#e8412a]">
         <Link
  href="#next"
  className="
    absolute
    bottom-[40px]
    left-1/2
    -translate-x-1/2
    w-[30px]
    h-[30px]
    z-[999]
    animate-bounce
  "
>
  <Image
    src="/images/inner-down-arrow.png"
    alt="Scroll Down"
    width={30}
    height={30}
    className="w-full h-full object-contain"
  />
</Link></div>
        </div>                
      </section>

      <section id="next" className="min-h-screen flex flex-col lg:flex-row">
        <div className="w-full lg:w-1/2 bg-[#f04c3e] flex items-center">
          <div className="max-w-[660px] mx-auto px-[50px] py-[80px] w-full">
            <div className="flex flex-col lg:flex-row gap-[60px]">
              <div data-aos="fade-right" className="lg:w-1/2">
                <h2
                  className="text-white"
                  style={{
                    fontSize: "36px",
                    lineHeight: "46px",
                    fontFamily: '"Google Sans Flex", sans-serif',
                    fontWeight: 400,
                  }}
                >
                  We recognise the challenges faced by an agency owner when
                  seeking a development partner
                </h2>
              </div>

              <div data-aos="fade-left" className="lg:w-1/2 relative">
                <div className="absolute left-[12px] top-[10px] bottom-[10px] w-[2px] bg-[#ff8b80]" />

                {[
                  "Will the project be delivered to the quality we expect?",
                  "Will the deadlines be adhered to?",
                  "Will our design essence be fully understood?",
                  "Will the project exceed its budget?",
                ].map((item, index) => (
                  <div
                    key={index}
                    className="relative flex items-start mb-[50px]"
                  >
                    <div className="w-[26px] h-[26px] rounded-full border-[4px] border-[#ff8b80] bg-[#f04c3e] z-10 flex-shrink-0" />

                    <p
                      className="text-white ml-[20px]"
                      style={{
                        fontSize: "24px",
                        lineHeight: "1.25",
                        fontFamily: '"Google Sans Flex", sans-serif',
                      }}
                    >
                      {item}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="w-full lg:w-1/2 relative min-h-[500px] lg:min-h-screen">
          <Image
            src="/images/designagencies.png"
            alt="Agency Challenges"
            fill
            className="object-cover"
            priority
          />
        </div>
      </section>

      <section className="bg-[#3f3f3f] min-h-screen flex items-center">
        <div className="max-w-[1600px] mx-auto px-[50px] w-full py-[100px]">
          <h2 data-aos="fade-up"
            className="text-white font-semibold max-w-[1250px]"
            style={{
              fontSize: "clamp(42px,4vw,64px)",
              lineHeight: "1.1",
              fontFamily: '"Google Sans Flex", sans-serif',
            }}
          >
            We act as a seamless extension of your team, delivering dependable
            development with clear communication and on-time delivery.
          </h2>

          <div data-aos="fade-up" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-[80px] gap-y-[80px] mt-[90px]">
            {[
              "28 years of expertise in website development and outsourced solutions.",
              "Specialising in scalable, high-performance web applications.",
              "Expertise in modern frameworks, CMS platforms, and custom solutions.",
              "Seamless integration with client teams for smooth project execution.",
              "Cost-effective development with a focus on innovation.",
              "End-to-end support from planning to deployment and maintenance.",
            ].map((item, index) => (
              <div key={index}>
                <div className="w-[30px] h-[3px] bg-[#f04c3e] mb-[18px]" />

                <p
                  className="text-white"
                  style={{
                    fontSize: "30px",
                    lineHeight: "46px",
                    fontFamily: '"Google Sans Flex", sans-serif',
                  }}
                >
                  {item}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
