export default function Footer() {
  return (
    <footer className="w-full bg-[#373737] text-[#aaa] text-[16px] py-[21px]">
      <div className="max-w-[1600px] mx-auto px-[50px] flex items-center justify-between flex-wrap gap-2">

        <span>
          Creative Skills Digital Ltd | Registered in England, Company No. 10556234
        </span>

        <span>
          Drop Us a Line at{' '}
          <a href="mailto:hello@creativeskills.com?subject=Website Inquiry" className="text-[#f04c3e] hover:opacity-80 transition-opacity">
            hello@creativeskills.com
          </a>
        </span>

      </div>
    </footer>
  );
}
