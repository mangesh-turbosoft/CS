'use client';

import { useState, useRef } from "react";
import Link from "next/link";
import Image from "next/image";

export default function CaseStudies() {
  const [playing, setPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handlePlay = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setPlaying(true);
    }
  };

  return (
    <section className="w-full flex min-h-screen">

      <div className="w-1/2 relative bg-black flex flex-col">

        <div className="relative flex-1 overflow-hidden">
          <video ref={videoRef} className="w-full h-full object-cover">
            <source src="https://www.creativeskills.com/video/Rob-iflourish4.m4v" type="video/mp4" />
          </video>

          {!playing && <div className="absolute inset-0 bg-black/20" />}

          {!playing && (
            <button
              onClick={handlePlay}
              aria-label="Play video"
              className="absolute bottom-8 right-8 bg-transparent border-none cursor-pointer p-0"
            >
              <Image src="/images/play-btn.png" alt="Play" width={56} height={56} />
            </button>
          )}
        </div>

        <div className="px-8 py-6 bg-white">
          <p data-aos="fade-up" className="font-bold text-gray-500 text-[32px] leading-snug mb-2" style={{ fontFamily: "'Figtree', sans-serif" }}>
            Real Stories, Real Impact – Hear from Our Clients
          </p>
          <p data-aos="fade-up" className="text-gray-500 text-[26px] leading-relaxed" style={{ fontFamily: "'Figtree', sans-serif",lineHeight: '1.1' }}>
            Hear directly from our clients as they share their experiences and the results they achieved working with us.
          </p>
        </div>
      </div>

      <div className="w-1/2 flex flex-col">

        <div className="flex flex-1">

          <div className="w-1/2 bg-white flex items-center px-[35px] py-[16px]">
            <div data-aos="fade-down">
              <span className="block font-bold text-[#f04c3e] text-[32px] leading-[36px]" style={{ fontFamily: "'Figtree', sans-serif" }}>
                White-label Development
              </span>
              <p className="text-[#7b7b7b] text-[16px] leading-relaxed mt-4" style={{ fontFamily: "'Figtree', sans-serif" }}>
                Design agencies often face challenges scaling development capacity while maintaining quality and timelines. Our white-label web development service enables your team to stay focused on strategy, design, and client relationships while our experienced developers deliver reliable, high-quality builds behind the scenes.
              </p>
            </div>
          </div>

          <div
            className="w-1/2 relative overflow-hidden bg-cover bg-center"
            style={{ backgroundImage: "url('/images/processbg.jpg')" }}
          >
            <div className="absolute inset-0 bg-black/50" />
            <Link href="/process/" className="absolute inset-0 z-10 flex items-center justify-center no-underline">
              <h2 data-aos="zoom-in" className="text-white text-center font-bold" style={{ fontSize: '48px', lineHeight: '50px', fontFamily: "'Figtree', sans-serif" }}>
                The Process
              </h2>
            </Link>
          </div>
        </div>

        <div className="flex flex-1">

          <div className="w-1/2 relative bg-[#f04c3e]">
            <Link href="/services/" className="absolute inset-0 flex items-center justify-center no-underline">
              <h2 data-aos="zoom-in" className="text-white text-center font-bold" style={{ fontSize: '48px', lineHeight: '50px', fontFamily: "'Figtree', sans-serif" }}>
                Our Services
              </h2>
            </Link>
          </div>

          <div
            className="w-1/2 relative overflow-hidden bg-cover bg-center"
            style={{ backgroundImage: "url('/images/agenciesbg.jpg')" }}
          >
            <div className="absolute inset-0 bg-black/50" />
            <Link href="/design-agencies/" className="absolute inset-0 z-10 flex items-center justify-center no-underline">
              <h2 className="text-white text-center font-bold" style={{ fontSize: '48px', lineHeight: '50px', fontFamily: "'Figtree', sans-serif" }}>
                Design Agencies
              </h2>
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
}
