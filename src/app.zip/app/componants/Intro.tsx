'use client';

import { useState } from "react";
import Image from "next/image";

export default function Intro() {

  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <section id="next">

        {/* PART 1 - World Map */}
        <div className="w-full">
          <Image
            src="/images/cskills-map-new.png"
            alt="Creative Skills World Map"
            width={1920}
            height={500}
            className="w-full h-auto block"
            priority
          />
        </div>

              <div
          className="relative w-full h-[450px] bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/images/video-cover.png')" }}
        >
          <button data-aos="fade-left"
            onClick={() => setIsOpen(true)}
            className="absolute top-1/2 left-[50px] -translate-y-1/2 bg-[#f04c3e] text-white border-none cursor-pointer text-[22px] leading-[34px] px-[50px] py-[10px] whitespace-nowrap"
            style={{ fontFamily: "'Figtree', sans-serif" }}
          >
            <strong>Click here</strong> to view our workplace video
          </button>
        </div>

      </section>

            {isOpen && (
        <div
          className="fixed inset-0 z-[9999] bg-black/85 flex items-center justify-center"
          onClick={() => setIsOpen(false)}
        >
          <div
            className="relative w-[90vw] max-w-[1200px]"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setIsOpen(false)}
              className="absolute -top-11 right-0 bg-transparent border-none cursor-pointer"
            >
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6l12 12" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </button>

            <video className="w-full block" controls autoPlay loop>
              <source src="https://www.creativeskills.com/video/new-office.mp4" type="video/mp4" />
            </video>
          </div>
        </div>
      )}
    </>
  );
}
