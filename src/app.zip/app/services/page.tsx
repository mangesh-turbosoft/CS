import type { Metadata } from "next";

export const metadata: Metadata = {
  title:
    "Web Development Services | WordPress, HubSpot & Headless CMS | Creative Skills",
  description:
    "Explore expert web development services including WordPress development, HubSpot CMS implementation, Headless CMS solutions, website support and optimisation.",
  keywords: [
    "web development services",
    "wordpress development",
    "wordpress developers",
    "hubspot cms development",
    "hubspot website development",
    "headless cms development",
    "custom website development",
    "website maintenance",
    "website support",
    "website optimisation",
    "cms development",
    "frontend development",
    "backend development",
    "web agency services",
  ],
};

export default function Services() {
  return (
    <div className="pt-[70px]">
        <section className="relative max-w-[1600px] mx-auto px-[50px] min-h-screen flex flex-col justify-center bg-white">
        <h1 data-aos="fade-up"
          className="font-google-sans
            text-[#f04c3e]
            font-semibold
            leading-[1.1]
            mt-[0]
            mb-[30]
            text-[228px]
          "
        >
          Development Partner
        </h1>

        <p data-aos="fade-up"
          className="font-google-sans
            text-[#7b7b7b]
            font-medium
            max-w-full
            overflow-hidden
            clear-both
            mt-8
            text-[62px]
            leading-[72px]
          "
        >
         Helping agencies scale website delivery without stretching internal teams.
        </p>

        <a
          href="#section1"
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[#e8412a]"
        >
          <svg
            width="38"
            height="38"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </a>
      </section>

      <section
        id="section1"
        className="relative min-h-screen flex items-center overflow-hidden"
        style={{
          backgroundImage: "url('/images/apps-bg-new-1.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="absolute inset-0 bg-black/45" />

        <div className="relative z-10 max-w-[1600px] mx-auto px-[50px] w-full">
          <div data-aos="fade-up" className="max-w-[600px]">
            <h2
              className="text-white mb-10"
              style={{
                fontSize: "72px",
                lineHeight: "72px",
                fontWeight: 600,
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              WordPress
            </h2>

            <p
              className="text-white mb-10"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              We specialise in premium WordPress development for design
              agencies, crafting high-performance, visually stunning websites
              that align with their creative vision. Our team provides tailored
              solutions for flexibility, speed, and seamless user experiences.
            </p>

            <p
              className="text-white mb-10"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              We take pride in our work and do not use page builders or
              readymade themes, ensuring each website is a one-of-a-kind
              creation.
            </p>

            <a
              href="mailto:hello@creativeskills.com"
              className="text-white"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              <span className="text-[#f04c3e] font-semibold">Click here</span>{" "}
              to receive examples of our work.
            </a>
          </div>
        </div>
      </section>

      <section className="min-h-screen flex flex-col lg:flex-row">
        <div className="w-full lg:w-1/2 bg-[#f04c3e] text-white">
          <div className="max-w-[720px] mx-auto px-[80px] py-[100px]">
            <img data-aos="zoom-in"
              src="/images/software-icon.png"
              alt=""
              className="w-[120px] mb-12"
            />

            <h2 data-aos="fade-up"
              className="mb-10"
              style={{
                fontSize: "72px",
                lineHeight: "72px",
                fontWeight: 600,
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              Headless CMS
            </h2>

            <p data-aos="fade-up"
              className="mb-10"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              Experience the flexibility and power of modern web architectures
              through our headless CMS development services using platforms like
              <strong> Strapi, Contentful, or Sanity.</strong>
            </p>

            <p data-aos="fade-up"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              Whether you are looking to migrate your content, optimise your
              existing setup, or develop a new digital strategy, we are here to
              ensure your success with innovative solutions tailored to your
              unique needs.
            </p>
          </div>
        </div>

        <div className="w-full lg:w-1/2 bg-[#8c8c8c] text-white">
          <div className="max-w-[720px] mx-auto px-[80px] py-[100px]">
            <img data-aos="zoom-in"
              src="/images/web-icon.png"
              alt=""
              className="w-[120px] mb-12"
            />

            <h2 data-aos="fade-up"
              className="mb-10"
              style={{
                fontSize: "72px",
                lineHeight: "72px",
                fontWeight: 600,
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              HubSpot Content Hub
            </h2>

            <p data-aos="fade-up"
              className="mb-10"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              We provide expert HubSpot development services to help businesses
              enhance marketing, sales, and customer service.
            </p>

            <p data-aos="fade-up"
              style={{
                fontSize: "30px",
                lineHeight: "46px",
                fontFamily: '"Google Sans Flex", sans-serif',
              }}
            >
              With deep expertise in HubSpot, we help businesses maximise lead
              generation and personalise customer journeys.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
